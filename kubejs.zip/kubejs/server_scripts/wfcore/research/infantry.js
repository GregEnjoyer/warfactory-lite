// Infantry research tab — all category('infantry') nodes.
// Runs in ServerEvents.recipes (fires on server start AND /reload).
ServerEvents.recipes(event => {

    WFResearch.builder('shotgun1')
        .category('infantry').pos(0, 0)
        .nodeColor(0xFF2F6BD8)
        .name('Infantry Combat 1')
        .description('Boomsticks')
        .runs(5).ticksPerRun(300).eut(32).cwuPerRun(0)
        .unlocks(
            Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"tacz:db_long",HasBulletInBarrel:1b}'),
            Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:1897",HasBulletInBarrel:1b}'),
            Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"tacz:m870",HasBulletInBarrel:1b}')
        )
        .icon(Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"tacz:m870",HasBulletInBarrel:1b}'))
        .register()

        WFResearch.builder('rifle1')
        .category('infantry').pos(0, 5)
        .nodeColor(0xFF2F6BD8)
        .name('Semi Auto Rifles')
        .description('Basic Semi Auto Rifles, some of the greatest battle implements ever made')
        .runs(5).ticksPerRun(300).eut(32).cwuPerRun(0)
        .unlocks(
            Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:m1",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:svt_40",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:g43",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:m1g",HasBulletInBarrel:1b}'),
        )
        .icon(Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:m1g",HasBulletInBarrel:1b}'))
        .register()
        WFResearch.builder('SMG')
        .category('infantry').pos(5, 5)
        .nodeColor(0xFF2F6BD8)
        .name('Semi Auto Rifles')
        .description('Sub-machineguns are good for close quarters, and for looking cool')
        .runs(5).ticksPerRun(300).eut(32).cwuPerRun(0)
        .unlocks(
            Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:m1",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:pps",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:t100l",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:m1a1",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:sten",HasBulletInBarrel:1b}'),
        )
        .icon(Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:m1g",HasBulletInBarrel:1b}'))
        .register()
        //MV
        WFResearch.builder('rifle2')
        .category('infantry').pos(0, 10)
        .nodeColor(0xFF2F6BD8)
        .name('Assault Rifles')
        .description(' You know what they do, you arent dumb, youve played an FPS before, I hope.')
        .runs(5).ticksPerRun(300).eut(64).cwuPerRun(0)
        .unlocks(
            Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"tacz:fn_fal",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"tacz:type_81",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"tacz:ak47",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"tacz:m4a1",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ronmc:ga41",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"tacz:scar",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"tacz:hk_g3",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ronmc:g36c",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"tacz:aug",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"tacz:m16a1",HasBulletInBarrel:1b}'),
        )
        .icon(Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"tacz:fn_fal",HasBulletInBarrel:1b}'))
        .register()

        WFResearch.builder('heavy1')
        .category('infantry').pos(0, 15)
        .nodeColor(0xFF2F6BD8)
        .name('Machine Guns')
        .description('heavy, but go brrrr longer. (the ww2 ones are here for balance)')
        .runs(5).ticksPerRun(300).eut(64).cwuPerRun(0)
        .unlocks(
            Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:mg42",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"tacz:rpk",HasBulletInBarrel:1b}'),
                Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:mg34",HasBulletInBarrel:1b}'),
                Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:1918a",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:dp28",HasBulletInBarrel:1b}'),
                 Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"tacz:m249",HasBulletInBarrel:1b}'),
        )
        .icon(Item.of('tacz:modern_kinetic_gun', '{GunCurrentAmmoCount:2,GunId:"ww:mg42",HasBulletInBarrel:1b}'))
        .register()

})
